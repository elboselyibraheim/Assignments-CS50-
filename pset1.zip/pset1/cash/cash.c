#include <stdio.h>
#include <cs50.h>
#include <math.h>

int main (void)
{
    float dollars;

    do
    {
        dollars = get_float(" change owed: "); //get input from user
    }
    while( dollars < 0 );

    int cents = round(dollars * 100);
    int coins =0;

    while (cents >= 25) // check about the first hight number with me 
    {
        cents -= 25;
        coins++;
    }

    while (cents >= 10) // check about the second hight number with me 
    {
        cents -= 10;
        coins++;
    }

    while (cents >= 5) // check about the third hight number with me 
    {
        cents -= 5;
        coins++;
    }

    while (cents >= 1) // check about the forth hight number with me 
    {
        cents -= 1;
        coins++;
    }

    printf("%i\n", coins);

}