#include <stdio.h>
#include <cs50.h>

int main (void)
{
    int h;
    do
    {
        h = get_int("hight : "); // askeing for User input 
    }
    while (h < 1 || h > 8);

    for(int i = 0; i < h; i++) // make loop for raw 
    {
        for(int j = 0; j < h; j++) // make loop for colum
        {
            if( i + j >= h-1) // when raw+colum more than or equal hight
            printf("#");
            else
            printf(" ");
        }
        printf("\n");
    }
}