-- Keep a log of any SQL queries you execute as you solve the mystery.
--All you know is that the theft took place on July 28, 2020 and that it took place on Chamberlin Street.
SELECT description
FROM crime_scene_reports
WHERE day=28 AND month=7 AND year=2020 AND street = "Chamberlin Street";


SELECT transcript
FROM interviews
WHERE day=28 and month=7 AND year=2020 and transcript LIKE "%courthouse%";

--Sometime within ten minutes of the theft, I saw the thief get into a car in the courthouse parking lot and drive away. If you have security footage from the courthouse parking lot, you might want to
--look for cars that left the parking lot in that time frame.

SELECT name
FROM people
JOIN courthouse_security_logs ON people.license_plate = courthouse_security_logs.license_plate
WHERE day=28 AND month=7 AND year=2020 AND hour=10 and minute >= 15 and minute < 25 AND activity = "exit";

--Patrick
--Ernest
--Amber
--Danielle
--Roger
--Elizabeth
--Russell
--Evelyn

SELECT DISTINCT name
FROM people
JOIN bank_accounts ON people.id = bank_accounts.person_id
JOIN atm_transactions ON bank_accounts.account_number = atm_transactions.account_number
WHERE day=28 AND year=2020 AND month=7 AND transaction_type="withdraw" AND atm_location="Fifer Street";

--Danielle
--Bobby
--Madison
--Ernest
--Roy
--Elizabeth
--Victoria
--Russell

SELECT name
FROM people
JOIN passengers ON people.passport_number = passengers.passport_number
WHERE flight_id =(
    SELECT id
    FROM flights
    WHERE day=29 AND month=7 AND year=2020
    ORDER BY hour, minute
    LIMIT 1)

-- Doris
--Roger
--Ernest
--Edward
--Evelyn
--Madison
--Bobby
--Danielle

SELECT DISTINCT name
FROM people
JOIN phone_calls ON people.phone_number = phone_calls.caller
WHERE day=28 AND month=7 AND year=2020 AND duration < 60;

-- Roger
--Evelyn
--Ernest
--Madison
--Russell
--Kimberly
--Bobby
--Victoria

SELECT city
FROM airports
WHERE id = (
    SELECT destination_airport_id
    FROM flights
    WHERE year="2020" AND month="7" AND day="29"
    ORDER BY hour,minute
    LIMIT 1);



SELECT name
FROM people
JOIN phone_calls ON people.phone_number = phone_calls.receiver
WHERE day="28" AND month="7" AND year="2020" AND duration < "60" AND caller = (
    SELECT phone_number
    FROM people
    WHERE name = "Ernest");

--Ernest
-- london

