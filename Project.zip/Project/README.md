# Flashcard
#### Video Demo:  <https://youtu.be/ENJmrx3v_ZM>
#### Description:
helps all learner languge or any things need to many time to repeat it
can easly remember to write it on the front of paper and in other side
the meaning of this word.



many times when i was learn a forgin languge class
that was very defecult to remember evry things every nons and verbs
so i have things this will help evry body to learn the new languge
by using card type on it the word that you want to remember and in the other side the meneing of this words with
the mother tone languege.
Now you can rebat this prosesing many time until you cant forgit this words
no more
