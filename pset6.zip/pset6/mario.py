from cs50 import get_int

while True:
    n = get_int("hight :")
    if n >= 1 and n <= 8:
        break
    
for i in range(n):
    for j in range(n):
        print("#" if i + j >= n-1 else " ", end="")
    print()