#include <cs50.h>
#include <stdio.h>
#include <math.h>

int main(void)
{
    int start_size;
    do
    {
        start_size = get_int("start_size: \n");
    }
    while (start_size < 9 );
    
    int end_size;
    do
    {
        end_size = get_int("End_size: \n");
    }
    while (end_size < start_size);
    
    int current_size = start_size;
    int years_passed = 0;
    while (current_size < end_size)
    {
        current_size = round ( current_size + current_size/3 - current_size/4);
        years_passed++;
    }
    printf("Years: %i \n", years_passed);
    
}